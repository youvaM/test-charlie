<!DOCTYPE html>
<html>
<head>
<title>Student Management | Add</title>
</head>
<body>
@if (session('status'))
<div class="alert alert-success" role="alert">
	<button type="button" class="close" data-dismiss="alert">×</button>
	{{ session('status') }}
</div>
@elseif(session('failed'))
<div class="alert alert-danger" role="alert">
	<button type="button" class="close" data-dismiss="alert">×</button>
	{{ session('failed') }}
</div>
@endif
<form action = "/create" method = "post">
	<input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
	<table>
	<tr>
	<td>id</td>
	<td><input type='text' name='id' /></td>
	<tr>
	<td>id_mat</td>
	<td><input type="text" name='id_mat'/></td>
	</tr>

	<td>identification</td>
	<td><input type="text" name='identification'/></td>
	</tr>
    

	<tr>
	<td>serial_number</td>
	<td><input type="text" name='serial_number'/></td>
	</tr>


	<tr>
	<td>region</td>
	<td><input type="text" name='region'/></td>
	</tr>

	<tr>
	<td>id_chantier</td>
	<td><input type="text" name='id_chantier'/></td>
	</tr>
    
	<tr>
	<td>id_zone_stockage</td>
	<td><input type="text" name='id_zone_stockage'/></td>
	</tr>

	<tr>
	<td>site</td>
	<td><input type="text" name='site'/></td>
	</tr>  
    
	<tr>
	<td>id_site</td>
	<td><input type="text" name='id_site'/></td>
	</tr>
    
	<tr>
	<td>back_shed</td>
	<td><input type="text" name='back_shed'/></td>
	</tr>
	
	<tr>
	<td>in_control</td>
	<td><input type="text" name='in_control'/></td>
	</tr>
	
	<tr>
	<td>outControl</td>
	<td><input type="text" name='outControl'/></td>
	</tr>
	
	<tr>
	<td>inControl_cp</td>
	<td><input type="text" name='inControl_cp'/></td>
	</tr>

	<tr>
	<td>outControl_cp</td>
	<td><input type="text" name='outControl_cp'/></td>
	</tr>

	<tr>
	<td>observation</td>
	<td><input type="text" name='observation'/></td>
	</tr>

	<tr>
	<td>use_rate</td>
	<td><input type="text" name='use_rate'/></td>
	</tr>
    
	<tr>
	<td>lost</td>
	<td><input type="text" name='lost'/></td>
	</tr>

	<tr>
	<td>price</td>
	<td><input type="text" name='price'/></td>
	</tr>

	<tr>
	<td>status</td>
	<td><input type="text" name='status'/></td>
	</tr>

    
	<tr>
	<td>control_place</td>
	<td><input type="text" name='control_place'/></td>
	</tr>

	<tr>
	<td>id_affiliate</td>
	<td><input type="text" name='id_affiliate'/></td>
	</tr>

	<tr>
	<td>completed</td>
	<td><input type="text" name='completed'/></td>
	</tr>

	<tr>
	<td>created_at</td>
	<td><input type="text" name='created_at'/></td>
	</tr>

	<tr>
	<td>updated_at</td>
	<td><input type="text" name='status'/></td>
	</tr>


















	<tr>
	<td colspan = '2'>
	<input type = 'submit' value = "Add Client"/>
	</td>
	</tr>
	</table>
</form>
</body>
</html>