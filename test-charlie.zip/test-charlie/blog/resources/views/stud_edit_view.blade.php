

<!Doctype html>
<html>
<head>
<title>Liste des clients</title>

<!-- library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">

<!-- library bootstrap -->
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>

</head>
<body>
<br>
<br>
    <div class="container">
        @if(Session::has('message'))
            <div class="alert-success text-center" id="res_message">
                {{ Session::get('message') }}
            </div>
        @endif
            <script>
            $(document).ready(function(){
                setTimeout(function() {
                    $('#res_message').hide();
                    },3000);
                });
                </script>

        @if(Session::has('delete'))
            <div class="alert-success text-center" id="res_message">
                {{ Session::get('delete') }}
            </div>
        @endif
            <script>
                $(document).ready(function(){
                setTimeout(function() {
                    $('#res_message').hide();
                    },3000);
                });
            </script>
       
<table id="tableHorizontalWrapper" class="table table-striped table-bordered table-sm text-center" cellspacing="0"width="50%">
            <tr>
            <td>id</td> 
                <td>id</td>
                <td>id_mat</td>
                <td>identification</td>
                <td>serial_number</td>
                <td>region</td>
                <td>id_chantier</td>
                <td>id_zone_stockage</td>
                <td>site</td>
                <td>id_site</td>
                <td>back_shed</td>
                <td>in_control</td>
                <td>outControl</td>
                <td>inControl_cp</td>
                <td>outControl_cp</td>
                <td>observation</td>
                <td>use_rate</td>
                <td>lost</td>
                <td>price</td>
                <td>status</td>
                <td>control_place</td>
                <td>id_affiliate</td>
                <td>completed</td>
                <td>created_at</td>
                <td>updated_at</td>
            
            </tr>
            @foreach ($users as $user)
            <tr>

                <td>{{ $user->id }}</td>
                <td>{{ $user->id }}</td>
                <td>{{ $user->id_mat }}</td>
                <td>{{ $user->identification }}</td>
                <td>{{ $user->serial_number }}</td>
                <td>{{ $user->region }}</td>
                <td>{{ $user->id_chantier }}</td>
                <td>{{ $user->id_zone_stockage }}</td>
                <td>{{ $user->site }}</td>
                <td>{{ $user->id_site }}</td>
                <td>{{ $user->back_shed }}</td>
                <td>{{ $user->in_control }}</td>
                <td>{{ $user->outControl }}</td>
                <td>{{ $user->inControl_cp }}</td>
                <td>{{ $user->outControl_cp }}</td>
                <td>{{ $user->observation }}</td>
                <td>{{ $user->use_rate }}</td>
                <td>{{ $user->lost }}</td>
                <td>{{ $user->price }}</td>
                <td>{{ $user->status }}</td>
                <td>{{ $user->control_place }}</td>
                <td>{{ $user->id_affiliate }}</td>
                <td>{{ $user->completed }}</td>
                <td>{{ $user->created_at }}</td>
                <td>{{ $user->updated_at }}</td>

                <td><a href = 'edit/{{ $user->id }}'>Edit</a></td>
                <td><a onClick="return confirm('Are you sure you want to delete?')" href = 'delete/{{ $user->id }}'>Delete</a></td>
            </tr>
            @endforeach
        </table>
    </div>
</body>
</html>