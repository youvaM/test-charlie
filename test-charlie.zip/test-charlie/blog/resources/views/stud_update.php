

<!DOCTYPE html>
<html>
<head>
<title>Client Edit</title>
<!-- library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">

<!-- library bootstrap -->
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>

</head>
<body>
    <div class="container">
        <form action = "/edit/<?php echo $users[0]->id; ?>" method = "post">
            <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
            <table>
                <tr>
                    <td>id</td>
                    <td>
                    <input type = 'text' class="form-control input-sm" name = 'id'value = '<?php echo$users[0]->id; ?>'/> </td>
                    </tr>
                    <tr>
                    <td>id_mat</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'id_mat'value = '<?php echo$users[0]->id_mat; ?>'/>
                    </td>
                    </tr>
                    <tr>
                    <td>identification</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'identification'value = '<?php echo$users[0]->identification; ?>'/>
                    </td>
                    </tr>
                    <tr>
                    <td>serial_number</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'serial_number'value = '<?php echo$users[0]->serial_number; ?>'/>
                    </td>
                    </tr>
                    <td>region</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'region'value = '<?php echo$users[0]->region; ?>'/>
                    </td>
                    </tr>
                    <td>id_chantier</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'id_chantier'value = '<?php echo$users[0]->id_chantier; ?>'/>
                    </td>
                    </tr>
                    <td>id_zone_stockage</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'id_zone_stockage'value = '<?php echo$users[0]->id_zone_stockage; ?>'/>
                    </td>
                    </tr>
                    <td>site</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'site'value = '<?php echo$users[0]->site; ?>'/>
                    </td>
                    </tr>
                    <td>id_site</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'id_site'value = '<?php echo$users[0]->id_site; ?>'/>
                    </td>
                    </tr>
                        
                    <td>back_shed</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'back_shed'value = '<?php echo$users[0]->back_shed; ?>'/>
                    </td>
                    </tr>

                    <td>in_control</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'in_control'value = '<?php echo$users[0]->in_control; ?>'/>
                    </td>
                    </tr>

                    <td>outControl</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'outControl'value = '<?php echo$users[0]->outControl; ?>'/>
                    </td>
                    </tr>

                    <td>inControl_cp</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'inControl_cp'value = '<?php echo$users[0]->inControl_cp; ?>'/>
                    </td>
                    </tr>

                    <td>outControl_cp</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'outControl_cp'value = '<?php echo$users[0]->outControl_cp; ?>'/>
                    </td>
                    </tr>

                    <td>observation</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'observation'value = '<?php echo$users[0]->observation; ?>'/>
                    </td>
                    </tr>

                    <td>use_rate</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'use_rate'value = '<?php echo$users[0]->use_rate; ?>'/>
                    </td>
                    </tr>

                    <td>lost</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'lost'value = '<?php echo$users[0]->lost; ?>'/>
                    </td>
                    </tr>

                    <td>price</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'price'value = '<?php echo$users[0]->price; ?>'/>
                    </td>
                    </tr>

                   
                    <td>status</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'status'value = '<?php echo$users[0]->status; ?>'/>
                    </td>
                    </tr>


                    <td>control_place</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'control_place'value = '<?php echo$users[0]->control_place; ?>'/>
                    </td>
                    </tr>

                    <td>id_affiliate</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'id_affiliate'value = '<?php echo$users[0]->id_affiliate; ?>'/>
                    </td>
                    </tr>

                    <td>completed</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'completed'value = '<?php echo$users[0]->completed; ?>'/>
                    </td>
                    </tr>

                    <td>created_at</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'created_at'value = '<?php echo$users[0]->created_at; ?>'/>
                    </td>
                    </tr>

                    <td>updated_at</td>
                    <td>
                    <input type = 'text'class="form-control input-sm" name = 'updated_at'value = '<?php echo$users[0]->updated_at; ?>'/>
                    </td>
                    </tr>


                    <tr>
                    <br>
                    <td colspan = '2'>
                    <input type = 'submit'class="btn btn-danger" value = "Update Client" />
                    </td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>