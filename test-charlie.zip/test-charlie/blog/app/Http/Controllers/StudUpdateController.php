<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
class StudUpdateController extends Controller 
{
    public function index()
    {
        $users = DB::select('SELECT * FROM charlie_materials_filiale1');
        return view('stud_edit_view',['users'=>$users]);
    }
    public function show($id) 
    {
        $users = DB::select('SELECT * FROM charlie_materials_filiale1 WHERE id = ?',[$id]);
        return view('stud_update',['users'=>$users]);
    }
    public function edit(Request $request,$id)
    {
        $id = $request->input('id');
        $id_mat = $request->input('id_mat');
        $identification = $request->input('identification');
        $serial_number = $request->input('serial_number');
        $region = $request->input('region');
        $id_chantier = $request->input('id_chantier');
        $id_zone_stockage = $request->input('id_zone_stockage');
        $site = $request->input('site');
        $id_site = $request->input('id_site');
        $back_shed = $request->input('back_shed');
        $in_control = $request->input('in_control');
        $outControl = $request->input('outControl');
        $inControl_cp = $request->input('inControl_cp');
        $outControl_cp = $request->input('outControl_cp');
        $observation = $request->input('observation');
        $use_rate = $request->input('use_rate');
        $lost = $request->input('lost');
        $price = $request->input('price');
        $status = $request->input('status');
        $control_place = $request->input('control_place');
        $id_affiliate = $request->input('id_affiliate');
        $completed = $request->input('completed');
        $created_at = $request->input('created_at');
        $updated_at = $request->input('updated_at');





        DB::update('UPDATE charlie_materials_filiale1 SET id = ?,id_mat=?,identification=?,serial_number=?,region=?,
        id_chantier=?,id_zone_stockage=?,site=?,id_site=?,back_shed=?,in_control=?,outControl=?,inControl_cp=?,outControl_cp=?,observation=?,use_rate=?,
        lost=?,price=?,status=?,control_place=?,id_affiliate=?,completed=?,created_at=?,updated_at=?
          WHERE id = ?',[$id,$id_mat,$identification,$serial_number,$region,$id_chantier,$id_zone_stockage,$site,$id_site,$back_shed,
          $in_control,$outControl,$inControl_cp,$outControl_cp,$observation,$use_rate,$lost,$price,$status,$control_place,$id_affiliate,
          $completed,$created_at,$updated_at,$id]);
        return redirect('edit-records')->with('message' ,'Record updated successfully.');
       
    }
}