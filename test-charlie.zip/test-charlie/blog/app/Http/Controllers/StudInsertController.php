<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
class StudInsertController extends Controller 
{
    public function insertform()
    {
        return view('stud_create');
    }
    public function insert(Request $request)
    {
        $id = $request->input('id');
        $id_mat = $request->input('id_mat');
        $identification = $request->input('identification');
        $serial_number = $request->input('serial_number');
        $region = $request->input('region');
        $id_chantier = $request->input('id_chantier');
        $id_zone_stockage = $request->input('id_zone_stockage');
        $site = $request->input('site');
        $id_site = $request->input('id_site');
        $back_shed = $request->input('back_shed');
        $in_control = $request->input('in_control');
        $outControl = $request->input('outControl');
        $inControl_cp = $request->input('inControl_cp');
        $outControl_cp = $request->input('outControl_cp');
        $observation = $request->input('observation');
        $use_rate = $request->input('use_rate');
        $lost = $request->input('lost');
        $price = $request->input('price');
        $status = $request->input('status');
        $control_place = $request->input('control_place');
        $id_affiliate = $request->input('id_affiliate');
        $completed = $request->input('completed');
        $created_at = $request->input('created_at');
        $updated_at = $request->input('updated_at');



        $data=array('id'=>$id,"id_mat"=>
        $id_mat,"identification"=>$identification,"serial_number"=>$serial_number,"region"=>$region,"id_chantier"=>
        $id_chantier,"id_zone_stockage"=>$id_zone_stockage,"site"=>$site,"id_site"=>
        $id_site,"back_shed"=>$back_shed,"in_control"=>$in_control,"outControl"=>$outControl,"inControl_cp"=>$inControl_cp,"outControl_cp"=>
        $outControl_cp,"observation"=>$observation,"use_rate"=>$use_rate,"lost"=>$lost,"price"=>
        $price,"status"=>$status,"control_place"=>$control_place,"id_affiliate"=>$id_affiliate,"completed"=>$completed,"created_at"=>
        $created_at,"updated_at"=>$updated_at);
        DB::table('charlie_materials_filiale1')->insert($data);
        echo("les informations sont enregstrées");
        return redirect('insert')->with('insert' ,'Record inserted successfully.');  
    }
}